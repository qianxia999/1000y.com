<?php

return [
'item_daoju'	=>'道具',
'item_equip'	=>'装备',
'item_magic'	=>'武功',
];