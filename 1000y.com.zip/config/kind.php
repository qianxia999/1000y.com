<?php
return [
	'wugong'=>'武功',
	'ceng'=>'层',
	'zhuangbei'=>'装备',
	'item'=>'道具',
	'ditu'=>'地图',
];

/*'wugong'=>[
	'quan'=>'拳法',
	'jian'=>'剑法',
	'dao'=>'刀法',
	'qiang'=>'枪法',
	'chui'=>'槌法',
	'gong'=>'弓法',
	'tou'=>'投法',
	'bufa'=>'步法',
	'xinfa'=>'心法',
	'huti'=>'护体',
	'fuzhu'=>'辅助',
	'zhang'=>'掌风',
],

'ceng'=>[
	'1ceng'=>'一层',
	'2ceng'=>'上层',
	'3ceng'=>'三层',
],*/
