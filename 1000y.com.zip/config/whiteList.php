<?php

return [
	'account'=>[
		'account',
		'registerSubmit',
		'Login',
		'loginSubmit',
		'Forget',
		'forgetSubmit'
	],
	'login'		=>['sign','signSubmit','login','loginSubmit','logout'],
	'user'		=>['passwordForget','passwordForgetSubmit','userTerm'],
	'ajax'		=>[],
	'home'		=>[],
	'document'	=>['List','Info'],
	'daoju'		=>['List'],
	'magic'		=>['List'],
	'npc'		=>['List'],
	'offer'		=>['List','offer'],
	'equip'		=>['List'],
	'album'		=>['List','Info'],
	'cell'		=>['Guide'],
];