<?php

return [
  0 => "time",
  1 => "userid",
  2 => "state",
  3 => "coin"
];