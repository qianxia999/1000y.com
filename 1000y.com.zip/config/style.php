<?php
return 	[
'color'=>[
	'normal'	=>'无',
	'zihong'	=>'紫红',
	'lanse'		=>'蓝色',
	'hongse'	=>'红色',
	'jinse'		=>'金色',
	'chengse'	=>'橙色',
	'bold'		=>'粗体',
],
'font'=>[
	'normal'	=>'正常',
	'italic'	=>'斜体',
	'bold'		=>'粗体',
	'del'		=>'删除',
],
'background'=>[
	'normal'	=>'无',
	'zihong'	=>'紫红',
	'lanse'		=>'蓝色',
	'hongse'	=>'红色',
	'jinse'		=>'金色',
	'chengse'	=>'橙色',
],
];
