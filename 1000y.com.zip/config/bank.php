<?php

return [
	'gongshang'	=>'工商银行',
	'jianshe'	=>'建设银行',
	'nongye'	=>'农业银行',
	'zhongguo'	=>'中国银行',
	


];