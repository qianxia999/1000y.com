<?php
return [
	'index'			=>'/',
	'loginSuccess'	=>'/',
	'user'			=>'?user',
	'register'		=>'?account',
	'login'			=>'?account=Login',
	'forget'		=>'?account=Forget',
	'modify'		=>'?account=Modify',
	'bind'			=>'?account=MobileBind',
];