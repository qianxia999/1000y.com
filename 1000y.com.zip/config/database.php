<?php
return [
    'database_type' => 'mysql',
    'database_name' => '1000y',
    'server' => 'rm-huabei2mysql57o.mysql.rds.aliyuncs.com',
    'username' => 'wind',
    'password' => 'Wind123$',
    'charset' => 'utf8'
];

return [
    'database_type' => 'mysql',
    'database_name' => '1000y',
    'server' => '127.0.0.1',
    'username' => 'root',
    'password' => 'fcsnow',
    'charset' => 'utf8'
];