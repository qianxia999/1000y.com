<?php
return [
	'document'	=>1,
	'map'		=>2,
	'item'		=>3,
	'npcKind'	=>4,
	'magicKind'	=>5,
	'magicCeng'	=>6,
	'daojuKind'	=>7,
	'equipBrand'=>8,
	'equipKind'	=>9,
	'source'	=>10,
	'album'		=>11,
];