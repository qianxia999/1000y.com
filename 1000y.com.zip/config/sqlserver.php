<?php
return [
    'database_type' => 'mssql',
    'database_name' => 'mssql1000y',
    'server' => '192.168.0.193',
    'username' => 'sa',
    'password' => '123123',
    'charset' => 'utf8'
];