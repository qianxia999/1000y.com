<?php
return [
'user'	=>'user',
'userDefault'	=>'user/avatar.png',
'userAvatar'	=>'user',
'goodsAvatar'	=>'goods/avatar',
'goodsPhoto'	=>'goods',
'goodsDefault'	=>'goods/goods.png',
'qrcode'		=>'qrcode',
'logo'			=>'logo.png',
'npc'			=>'npc',
'magic'			=>'magic',
'equip'			=>'equip',
'daoju'			=>'daoju',
'album'			=>'album',
'source'		=>'source',
'category'		=>'category',
'avatarDefault'	=>'avatar.png',
];