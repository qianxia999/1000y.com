<?php

$index='home';

define('AUTHKEY','USERAUTH');
#define('USER',66);

require_once '../core/core.php';
exit;