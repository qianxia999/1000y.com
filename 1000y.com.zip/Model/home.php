<?php namespace Model;

class Home extends \core\DB{

}